import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Set the style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("tab10")
plt.rcParams['figure.figsize'] = [12, 8]

# Create the dataframe from the data
data = {
    'State': [
        'Andaman and Nicobar Islands', 'Andaman and Nicobar Islands', 'Andaman and Nicobar Islands', 'Andaman and Nicobar Islands',
        'Andhra Pradesh', 'Andhra Pradesh', 'Andhra Pradesh',
        'Arunachal Pradesh', 'Arunachal Pradesh', 'Arunachal Pradesh',
        'Assam', 'Assam', 'Assam', 'Assam', 'Assam', 'Assam',
        'Bihar', 'Bihar', 'Bihar', 'Bihar', 'Bihar', 'Bihar',
        'Chandigarh', 'Chandigarh', 'Chandigarh',
        'Chhattisgarh', 'Chhattisgarh', 'Chhattisgarh', 'Chhattisgarh',
        'Dadra and Nagar Haveli', 'Dadra and Nagar Haveli', 'Dadra and Nagar Haveli',
        'Goa', 'Goa', 'Goa',
        'Gujarat', 'Gujarat', 'Gujarat', 'Gujarat',
        'Haryana', 'Haryana', 'Haryana',
        'Himachal Pradesh', 'Himachal Pradesh', 'Himachal Pradesh',
        'Jammu and Kashmir', 'Jammu and Kashmir', 'Jammu and Kashmir',
        'Jharkhand', 'Jharkhand', 'Jharkhand', 'Jharkhand', 'Jharkhand',
        'Karnataka', 'Karnataka', 'Karnataka', 'Karnataka',
        'Kerala', 'Kerala', 'Kerala', 'Kerala', 'Kerala',
        'Madhya Pradesh', 'Madhya Pradesh', 'Madhya Pradesh',
        'Maharashtra', 'Maharashtra', 'Maharashtra', 'Maharashtra', 'Maharashtra',
        'Manipur', 'Manipur', 'Manipur', 'Manipur', 'Manipur', 'Manipur',
        'Meghalaya', 'Meghalaya', 'Meghalaya', 'Meghalaya', 'Meghalaya', 'Meghalaya',
        'Mizoram', 'Mizoram', 'Mizoram',
        'Nagaland', 'Nagaland', 'Nagaland',
        'Odisha', 'Odisha', 'Odisha', 'Odisha', 'Odisha', 'Odisha',
        'Puducherry', 'Puducherry', 'Puducherry', 'Puducherry', 'Puducherry', 'Puducherry',
        'Punjab', 'Punjab', 'Punjab',
        'Rajasthan', 'Rajasthan', 'Rajasthan',
        'Sikkim', 'Sikkim', 'Sikkim',
        'Tamil Nadu', 'Tamil Nadu', 'Tamil Nadu',
        'Telangana', 'Telangana', 'Telangana',
        'Tripura', 'Tripura', 'Tripura',
        'Uttar Pradesh', 'Uttar Pradesh', 'Uttar Pradesh', 'Uttar Pradesh',
        'Uttarakhand', 'Uttarakhand', 'Uttarakhand', 'Uttarakhand',
        'West Bengal', 'West Bengal', 'West Bengal', 'West Bengal', 'West Bengal', 'West Bengal'
    ],
    'Season': [
        'Autumn', 'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year', 'Winter',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year', 'Winter',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Summer', 'Whole Year',
        'Kharif', 'Rabi', 'Winter',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Summer', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Autumn', 'Kharif', 'Rabi', 'Whole Year', 'Winter',
        'Kharif', 'Rabi', 'Summer', 'Whole Year',
        'Autumn', 'Kharif', 'Summer', 'Whole Year', 'Winter',
        'Kharif', 'Rabi', 'Whole Year',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year', 'Winter',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year', 'Winter',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year', 'Winter',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year', 'Winter',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Whole Year',
        'Kharif', 'Rabi', 'Summer', 'Whole Year',
        'Kharif', 'Rabi', 'Summer', 'Whole Year',
        'Autumn', 'Kharif', 'Rabi', 'Summer', 'Whole Year', 'Winter'
    ],
    'Production': [
        25248.95, 214239.06, 11598.92, 717972153.1,
        200336054, 98156193, 17026098049,
        4141028.6, 157883, 2525001,
        8230196, 15782850, 8404649, 17171024, 1996667293, 65495747,
        23622936, 31029656.66, 103402165, 15679752, 124903630, 67845457,
        8224, 40053.5, 15679,
        89775225, 9228963.01, 1494, 1946226,
        640830, 69815, 1137226,
        1151845.58, 429152, 504174760,
        176315379, 51737400, 12268700, 283969858,
        88593481, 173272098, 119408311,
        10134207.5, 6723873, 947088.1,
        9070244.8, 4124447.7, 96323.2,
        1923687.84, 32220.12, 1609846.66, 91369.88, 7120617.25,
        175028059.3, 43860390.2, 19552520, 624988842.2,
        3442449.33, 120672.95, 2093790.53, 97869331257, 5057205.72,
        166243566.9, 191648533.7, 90948638.07,
        19695, 536463806.7, 70912135.5, 2957812, 653287157,
        244230, 3619792, 18910, 28600, 1111195, 208190,
        525139, 4723682, 725401, 358352, 4378228, 1401694,
        1187227.3, 67405.53, 406907,
        10143947, 1378761, 1243242,
        14324748.1, 21054246.8, 1378446.8, 13628421.5, 7828748.7, 102689458.2,
        32535, 3475037, 293646, 183675, 380686041, 53568,
        217036762, 279460439, 89887800,
        103210376.5, 154932976, 23176918,
        1931617, 216946, 287172,
        130814574.7, 3941610.1, 11941686864,
        121775409, 46917578, 166454943,
        11036883, 84058, 1401976,
        1721677764, 647943580.5, 4037386, 860833932,
        21074505, 14308338, 525505, 96269007,
        12022903, 152126828, 136230260, 82170893, 831812840.7, 183540665
    ]
}

df = pd.DataFrame(data)

# Add the total production per state
state_totals = df.groupby('State')['Production'].sum().reset_index()
state_totals = state_totals.sort_values('Production', ascending=False)

# 1. Bar chart of top 10 states by production
plt.figure(figsize=(14, 8))
top_10 = state_totals.head(10)

sns.barplot(x='Production', y='State', data=top_10)
plt.title('Top 10 States by Agricultural Production', fontsize=16)
plt.xlabel('Production (in units)', fontsize=12)
plt.ylabel('State', fontsize=12)
plt.ticklabel_format(style='scientific', axis='x', scilimits=(0,0))
plt.tight_layout()
plt.savefig('top_10_states.png', dpi=300, bbox_inches='tight')
plt.close()

# 2. Production by season (across all states)
season_totals = df.groupby('Season')['Production'].sum().reset_index()
season_totals = season_totals.sort_values('Production', ascending=False)

plt.figure(figsize=(12, 6))
sns.barplot(x='Season', y='Production', data=season_totals)
plt.title('Agricultural Production by Season (All States)', fontsize=16)
plt.xlabel('Season', fontsize=12)
plt.ylabel('Production (in units)', fontsize=12)
plt.ticklabel_format(style='scientific', axis='y', scilimits=(0,0))
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('production_by_season.png', dpi=300, bbox_inches='tight')
plt.close()

# 3. Heatmap of states and seasons
# Create a pivot table
pivot_data = df.pivot_table(values='Production', index='State', columns='Season', aggfunc='sum', fill_value=0)

# Normalize the data for better visualization (log scale)
pivot_norm = np.log10(pivot_data + 1)  # +1 to avoid log(0)

plt.figure(figsize=(16, 14))
sns.heatmap(pivot_norm, cmap='YlGnBu', linewidths=0.5)
plt.title('Heatmap of Agricultural Production by State and Season (Log Scale)', fontsize=16)
plt.xlabel('Season', fontsize=12)
plt.ylabel('State', fontsize=12)
plt.tight_layout()
plt.savefig('state_season_heatmap.png', dpi=300, bbox_inches='tight')
plt.close()

# 4. Pie chart of top 5 states' contribution to total production
total_production = state_totals['Production'].sum()
top_5_states = state_totals.head(5)
other_states = pd.DataFrame({
    'State': ['Others'],
    'Production': [total_production - top_5_states['Production'].sum()]
})
pie_data = pd.concat([top_5_states, other_states])

plt.figure(figsize=(10, 10))
plt.pie(pie_data['Production'], labels=pie_data['State'], autopct='%1.1f%%', startangle=90, shadow=True)
plt.axis('equal')
plt.title('Share of Top 5 States in Total Agricultural Production', fontsize=16)
plt.tight_layout()
plt.savefig('top_5_states_pie.png', dpi=300, bbox_inches='tight')
plt.close()

# 5. Seasonal distribution for top 5 states
top_5_states_list = state_totals.head(5)['State'].tolist()
top_5_df = df[df['State'].isin(top_5_states_list)]

plt.figure(figsize=(14, 10))
g = sns.catplot(x='State', y='Production', hue='Season', data=top_5_df, kind='bar', height=6, aspect=2)
plt.title('Seasonal Production Distribution for Top 5 States', fontsize=16)
plt.xlabel('State', fontsize=12)
plt.ylabel('Production (in units)', fontsize=12)
plt.xticks(rotation=45)
plt.ticklabel_format(style='scientific', axis='y', scilimits=(0,0))
plt.tight_layout()
plt.savefig('top_5_states_seasonal.png', dpi=300, bbox_inches='tight')
plt.close()

# 6. Stacked bar chart showing production types by state (for top 10 states)
top_10_states_list = state_totals.head(10)['State'].tolist()
top_10_df = df[df['State'].isin(top_10_states_list)]

pivot_top10 = top_10_df.pivot_table(values='Production', index='State', columns='Season', aggfunc='sum', fill_value=0)
pivot_top10 = pivot_top10.loc[top_10_states_list]  # Preserve original order

plt.figure(figsize=(16, 10))
pivot_top10.plot(kind='bar', stacked=True)
plt.title('Production by Season for Top 10 States', fontsize=16)
plt.xlabel('State', fontsize=12)
plt.ylabel('Production (in units)', fontsize=12)
plt.xticks(rotation=45)
plt.ticklabel_format(style='scientific', axis='y', scilimits=(0,0))
plt.legend(title='Season', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.savefig('top_10_stacked_season.png', dpi=300, bbox_inches='tight')
plt.close()

# 7. Horizontal bar chart showing production by state and season (excluding whole year for better comparison)
seasonal_df = df[df['Season'] != 'Whole Year']
seasonal_pivot = seasonal_df.pivot_table(values='Production', index='State', columns='Season', aggfunc='sum', fill_value=0)

# Top 15 states by seasonal production
top_seasonal = seasonal_df.groupby('State')['Production'].sum().nlargest(15).index
seasonal_pivot = seasonal_pivot.loc[top_seasonal]

plt.figure(figsize=(14, 12))
seasonal_pivot.plot(kind='barh', figsize=(14, 12))
plt.title('Seasonal Production by State (Top 15 States, Excluding Whole Year)', fontsize=16)
plt.xlabel('Production (in units)', fontsize=12)
plt.ylabel('State', fontsize=12)
plt.ticklabel_format(style='scientific', axis='x', scilimits=(0,0))
plt.legend(title='Season', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.savefig('seasonal_production_by_state.png', dpi=300, bbox_inches='tight')
plt.close()

# 8. Distribution of "Whole Year" vs seasonal production
df['Category'] = df['Season'].apply(lambda x: 'Whole Year' if x == 'Whole Year' else 'Seasonal')
category_production = df.groupby('Category')['Production'].sum().reset_index()

plt.figure(figsize=(10, 6))
sns.barplot(x='Category', y='Production', data=category_production)
plt.title('Whole Year vs Seasonal Production', fontsize=16)
plt.xlabel('Category', fontsize=12)
plt.ylabel('Production (in units)', fontsize=12)
plt.ticklabel_format(style='scientific', axis='y', scilimits=(0,0))
plt.tight_layout()
plt.savefig('whole_year_vs_seasonal.png', dpi=300, bbox_inches='tight')
plt.close()

# Print basic statistics
print("\nTotal Agricultural Production:", total_production)
print("\nTop 5 States by Production:")
for i, row in top_5_states.iterrows():
    print(f"{row['State']}: {row['Production']:,.0f} ({row['Production']/total_production*100:.1f}%)")

print("\nProduction by Season:")
for i, row in season_totals.iterrows():
    print(f"{row['Season']}: {row['Production']:,.0f} ({row['Production']/total_production*100:.1f}%)")

# Additional statistics
print("\nNumber of states/territories in the dataset:", df['State'].nunique())
print("Average production per state:", df.groupby('State')['Production'].sum().mean())

# Find states with highest production in each season
for season in df['Season'].unique():
    if season != 'Whole Year':
        top_state = df[df['Season'] == season].groupby('State')['Production'].sum().nlargest(1)
        print(f"\nState with highest {season} production: {top_state.index[0]} ({top_state.values[0]:,.0f})")

print("\nData Visualization Complete. Check the saved image files.")